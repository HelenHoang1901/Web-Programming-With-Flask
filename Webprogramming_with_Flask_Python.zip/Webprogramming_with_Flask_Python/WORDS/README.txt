Flask purposes:

- to create, manipulate and construct dynamicly pages following the format of CSS and HTML



- {% block body %}{% endblock %} ??? 
It's a yet language 
JINJA - a template language
FLASK by default supports JINJA

"Jinja is a web template engine for the Python programming language. 
It was created by Armin Ronacher and is licensed under a BSD License. 
Jinja is similar to the Django template engine but provides Python-like expressions 
while ensuring that the templates are evaluated in a sandbox."

BOOTSTRAP - CSS library
https://getbootstrap.com/docs/5.2/customize/components/

